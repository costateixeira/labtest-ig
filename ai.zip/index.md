# Home - Laboratory Test IG v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ig-empty/ImplementationGuide/smart.who.int.ig-empty | *Version*:0.1.0 |
| Draft as of 2025-11-12 | *Computable Name*:LabTest |

 This implementation guide and set of artifacts are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

This is an **example** IG.

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

### Dependencies

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (smart.who.int.ig-empty.r4)](package.r4.tgz) and [R4B (smart.who.int.ig-empty.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

No use of external IP (other than from the FHIR specification)

